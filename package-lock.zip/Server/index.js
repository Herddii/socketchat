let app = require('express')();
let http = require('http').Server(app);
let io = require('socket.io')(http);
var mysql	= require("mysql");

var db    =    mysql.createConnection({
      connectionLimit   :   100,
      host              :   '10.22.253.64',
      user              :   'root',
      password          :   '',
      database          :   'intra-mediakit',
      debug             :   false
});

db.connect(function(err){
    if (err) console.log(err)
})
var ga = ''
var message = []
var isInitNotes = false
var socketCount = 0
var chat = [];
var created_at = [];
var rooms = ['room1','room2','room3'];
app.get("/", function(req, res) {
    res.send("home");
});

http.listen(3001,"10.22.253.64", function(){
	console.log('listening in http://10.22.253.64:3001');
})
// io.on('connection', function(socket){
//   console.log('a user connected');
// });
io.on('connection',(socket)=>{
	console.log('a user connected');
	socket.on('disconnect',function(){
		io.emit('user-changed',{user:socket.nickname, event:'left'});
	});

	socket.on('set-nickname',(nickname)=>{
		console.log(nickname);
		socket.nickname = nickname.name;
		// db.query('SELECT * FROM tbl_user WHERE ID_BU="'+nickname.idbu+'"').on('result',function(data){
		// 	console.log(data);
		// 	var a = data.ID_BU;
		// 	if (a==1){
		// 		ga = 'room1';
		// 	} else if (a==2){
		// 		ga = 'room2';
		// 	} else{
		// 		ga = 'room3';
		// 	}
		// });
		if(nickname.idbu==11){
			ga = 'room1';
		} else {
			ga = 'room2';
		}
		// io.emit('user-changed',{user:nickname,event:'joined'});
		socket.room = ga;
		console.log(ga);
		// add the client's username to the global list
		// send client to room 1
		socket.join(ga);
		// console.log(socket.room);
		// echo to client they've connected
		// socket.emit('updatechat', 'SERVER', 'you have connected to '+ga+'');
		// echo to room 1 that a person has connected to their room
		socket.broadcast.to(ga).emit('updatechat', 'SERVER', socket.nickname + ' has connected to this room');
		socket.emit('updaterooms', rooms, ga);
	});

	socket.on('sendchat', function (data) {

		var sql = 'INSERT INTO tbl_group(id_user,chat,id_bu) VALUES("'+data.iduser+'","'+message.text+'","'+data.idbu+'")';
			db.query(sql, function (err, result) {
				if (err) throw err;
				console.log("1 record inserted");	
			});
		// console.log(socket.room);
		console.log(data);
		// we tell the client to execute 'updatechat' with 2 parameters
		io.sockets.in(socket.room).emit('updatechat', {text:data.text, name: socket.nickname, created: new Date()});
	});

	// socket.on('add-message',(message)=>{
	// 	console.log(message);
	// 	db.query('SELECT * FROM tbl_user WHERE username="'+message.user+'"').on('result',function(data){
	// 		var a = data.ID_USER;
	// 		var sql = 'INSERT INTO tbl_group(id_user,chat,id_bu) VALUES("'+data.ID_USER+'","'+message.text+'","'+data.ID_BU+'")';
	// 		db.query(sql, function (err, result) {
	// 			if (err) throw err;
	// 			console.log("1 record inserted");	
	// 		});
	// 		var view = 'SELECT * FROM tbl_group WHERE id_bu='+data.ID_BU+'';
	// 		db.query(view, function(err, das){
	// 			console.log(das);
	// 			if (err) throw err;
	// 			ga = {
	// 				text: das.chat
	// 			}
	// 		});
	// 	});
	// 		console.log(ga);
	// 	io.sockets.in(socket.room).emit('updatechat', socket.username, message);
	// 	// io.sockets.in(socket.room).emit('message',{text:message.text, from: socket.nickname, created: new Date()});
	// });

	socket.on('view-message',(message)=>{
		console.log(message);
		// user: this.nickname, id_bu: this.idbu, id_user: this.iduser
		var sql = 'SELECT tbl_group.chat as text, tbl_user.USER_NAME as name, tbl_group.created_at as created FROM tbl_group left join tbl_user on tbl_user.ID_USER = tbl_group.id_user WHERE tbl_group.ID_BU='+message.idbu+'';
			db.query(sql, function (err, result) {
				if (err) throw err;
				console.log(result);	
				// chat = result.chat;
				// created_at = result.created_at;
                io.emit('cbmessage',result);
			});
		// db.query('SELECT * FROM tbl_user WHERE username="'+message.user+'"').on('result',function(data){
		// 	var a = data.ID_USER;
		// 	console.log(data.ID_BU);
		// 	db.query('SELECT * FROM tbl_group left join tbl_user on tbl_user.ID_USER = tbl_group.id_user WHERE tbl_group.id_bu='+data.ID_BU+'')
  //           .on('result', function(asd){
  //           	console.log(asd);
  //           })
		// });
	})
});

